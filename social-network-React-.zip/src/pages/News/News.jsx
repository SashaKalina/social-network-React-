import React from 'react';
import s from './News.module.css'

const News = (props) => {
	return (
		<div>
			News
		</div>
			
		)
}
export default News;